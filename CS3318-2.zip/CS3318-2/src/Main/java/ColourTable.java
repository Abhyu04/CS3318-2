import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;

public class ColourTable {
    private HashSet<String> palette;
    private int paletteSize;

    public ColourTable(int paletteSize) {
        if (!isPowerTwo(paletteSize) || paletteSize < 2 || paletteSize > 1024) {
            throw new IllegalArgumentException("Invalid palette size, must be between 2 and 1024, and a power of two");
        }
        this.palette = new HashSet<>();
        this.paletteSize = paletteSize;
    }

    public void add(int redValue, int greenValue, int blueValue) {
        if (!isValidColourValue(redValue) || !isValidColourValue(greenValue) || !isValidColourValue(blueValue)) {
            throw new IllegalArgumentException("Invalid colour value provided");
        }

        String hexString = rgbToHexString(redValue, greenValue, blueValue);

        if (palette.contains(hexString)) {
            return;
        }
        if (palette.size() == paletteSize) {
            throw new IllegalStateException("Palette cannot exceed size specified at creation");
        }

        palette.add(hexString);
    }

    public void remove(int redValue, int greenValue, int blueValue) {
        if (!isValidColourValue(redValue) || !isValidColourValue(greenValue) || !isValidColourValue(blueValue)) {
            throw new IllegalArgumentException("Invalid colour value provided");
        }

        String hexString = rgbToHexString(redValue, greenValue, blueValue);

        if (!palette.contains(hexString)) {
            throw new IllegalArgumentException("Colour does not exist in palette");
        }

        palette.remove(hexString);
    }

    public void clearPalette() {
        palette.clear();
    }

    public String exportPalette() {
        if (palette.isEmpty()) {
            throw new IllegalStateException("Cannot export an empty palette");
        }
        return String.join(",", palette);
    }

    public void importPalette(String paletteString) {
        if (paletteString == null || paletteString.isEmpty()) {
            throw new IllegalArgumentException("Palette string cannot be null or empty");
        }

        String[] colours = paletteString.split(",");
        for (String colour : colours) {
            if (colour.length() != 6 || !colour.matches("[0-9A-Fa-f]{6}")) {
                throw new IllegalArgumentException("Invalid colour format in palette string: " + colour);
            }
            if (palette.size() == paletteSize) {
                throw new IllegalStateException("Cannot import more colours than the palette size");
            }
            palette.add(colour.toUpperCase());
        }
    }

    public int countColours() {
        return palette.size();
    }

    public boolean containsColor(int redValue, int greenValue, int blueValue) {
        if (!isValidColourValue(redValue) || !isValidColourValue(greenValue) || !isValidColourValue(blueValue)) {
            throw new IllegalArgumentException("Invalid colour value provided");
        }

        String hexString = rgbToHexString(redValue, greenValue, blueValue);
        return palette.contains(hexString);
    }

    public List<String> getAllColors(boolean sorted) {
        List<String> colorList = new ArrayList<>(palette);
        if (sorted) {
            Collections.sort(colorList);
        }
        return colorList;
    }

    public String findClosestColor(int redValue, int greenValue, int blueValue) {
        if (!isValidColourValue(redValue) || !isValidColourValue(greenValue) || !isValidColourValue(blueValue)) {
            throw new IllegalArgumentException("Invalid colour value provided");
        }

        if (palette.isEmpty()) {
            throw new IllegalStateException("Cannot find the closest color in an empty palette");
        }

        String closestColor = null;
        double minDistance = Double.MAX_VALUE;

        for (String hexColor : palette) {
            int paletteRed = Integer.parseInt(hexColor.substring(0, 2), 16);
            int paletteGreen = Integer.parseInt(hexColor.substring(2, 4), 16);
            int paletteBlue = Integer.parseInt(hexColor.substring(4, 6), 16);

            double distance = Math.sqrt(Math.pow(redValue - paletteRed, 2) +
                    Math.pow(greenValue - paletteGreen, 2) +
                    Math.pow(blueValue - paletteBlue, 2));

            if (distance < minDistance) {
                minDistance = distance;
                closestColor = hexColor;
            }
        }

        return closestColor;
    }

    @Override
    public String toString() {
        if (palette.isEmpty()) {
            return "ColourTable is empty.";
        }

        StringBuilder sb = new StringBuilder();
        sb.append("ColourTable: ").append(countColours()).append(" colours\n");
        for (String color : palette) {
            sb.append(color).append("\n");
        }
        return sb.toString();
    }

    private boolean isPowerTwo(int number) {
        return (number > 0) && ((number & (number - 1)) == 0);
    }

    private boolean isValidColourValue(int value) {
        return (0 <= value) && (value <= 255);
    }

    private String rgbToHexString(int r, int g, int b) {
        return String.format("%02X%02X%02X", r, g, b);
    }
}
