import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class ColourTableTest {

    @Test
    @DisplayName("Using a palette size that is too small")
    void testConstructorWithTooSmallPaletteSize() {
        Throwable exception = assertThrows(IllegalArgumentException.class, () -> new ColourTable(1));
        assertEquals("Invalid palette size, must be between 2 and 1024, and a power of two", exception.getMessage());
    }

    @Test
    @DisplayName("Using a palette size that is too large")
    void testConstructorWithTooLargePaletteSize() {
        Throwable exception = assertThrows(IllegalArgumentException.class, () -> new ColourTable(2048));
        assertEquals("Invalid palette size, must be between 2 and 1024, and a power of two", exception.getMessage());
    }

    @Test
    @DisplayName("Exporting a palette")
    void testExportPalette() {
        ColourTable colourTable = new ColourTable(16);
        colourTable.add(100, 100, 100);
        colourTable.add(200, 200, 200);
        String exported = colourTable.exportPalette();
        assertEquals("646464,C8C8C8", exported, "Exported palette should match the expected format");
    }

    @Test
    @DisplayName("Exporting an empty palette")
    void testExportEmptyPalette() {
        ColourTable colourTable = new ColourTable(16);
        Throwable exception = assertThrows(IllegalStateException.class, colourTable::exportPalette);
        assertEquals("Cannot export an empty palette", exception.getMessage());
    }

    @Test
    @DisplayName("Importing a palette")
    void testImportPalette() {
        ColourTable colourTable = new ColourTable(16);
        colourTable.importPalette("646464,C8C8C8");
        assertEquals(2, colourTable.countColours(), "Imported palette should contain two colours");
        assertTrue(colourTable.exportPalette().contains("646464"));
        assertTrue(colourTable.exportPalette().contains("C8C8C8"));
    }

    @Test
    @DisplayName("Importing a palette with invalid colour")
    void testImportInvalidPalette() {
        ColourTable colourTable = new ColourTable(16);
        Throwable exception = assertThrows(IllegalArgumentException.class, () -> colourTable.importPalette("INVALID,C8C8C8"));
        assertEquals("Invalid colour format in palette string: INVALID", exception.getMessage());
    }

    @Test
    @DisplayName("Importing a palette exceeding size")
    void testImportExceedingPaletteSize() {
        ColourTable colourTable = new ColourTable(4);
        Throwable exception = assertThrows(IllegalStateException.class, () -> colourTable.importPalette("646464,C8C8C8,323232,121212,000000"));
        assertEquals("Cannot import more colours than the palette size", exception.getMessage());
    }

    @Test
    @DisplayName("Check if a colour exists in the palette")
    void testContainsColor() {
        ColourTable colourTable = new ColourTable(16);
        colourTable.add(100, 100, 100);
        assertTrue(colourTable.containsColor(100, 100, 100), "Palette should contain the added colour");
        assertFalse(colourTable.containsColor(200, 200, 200), "Palette should not contain a colour that wasn't added");
    }

    @Test
    @DisplayName("Retrieve all colours in the palette (unsorted)")
    void testGetAllColorsUnsorted() {
        ColourTable colourTable = new ColourTable(16);
        colourTable.add(100, 100, 100);
        colourTable.add(200, 200, 200);
        List<String> colors = colourTable.getAllColors(false);
        assertTrue(colors.contains("646464"));
        assertTrue(colors.contains("C8C8C8"));
    }

    @Test
    @DisplayName("Retrieve all colours in the palette (sorted)")
    void testGetAllColorsSorted() {
        ColourTable colourTable = new ColourTable(16);
        colourTable.add(200, 200, 200);
        colourTable.add(100, 100, 100);
        List<String> colors = colourTable.getAllColors(true);
        assertEquals("646464", colors.get(0), "First colour should be the lexicographically smallest");
        assertEquals("C8C8C8", colors.get(1), "Second colour should be the lexicographically largest");
    }

    @Test
    @DisplayName("Find closest color in the palette")
    void testFindClosestColor() {
        ColourTable colourTable = new ColourTable(16);
        colourTable.add(100, 100, 100); // 646464
        colourTable.add(200, 200, 200); // C8C8C8
        colourTable.add(50, 50, 50);   // 323232

        String closestColor = colourTable.findClosestColor(105, 105, 105);
        assertEquals("646464", closestColor, "Closest color should be 646464");

        closestColor = colourTable.findClosestColor(210, 210, 210);
        assertEquals("C8C8C8", closestColor, "Closest color should be C8C8C8");
    }

    @Test
    @DisplayName("Find closest color in an empty palette")
    void testFindClosestColorInEmptyPalette() {
        ColourTable colourTable = new ColourTable(16);
        Throwable exception = assertThrows(IllegalStateException.class, () -> colourTable.findClosestColor(100, 100, 100));
        assertEquals("Cannot find the closest color in an empty palette", exception.getMessage());
    }

    @Test
    @DisplayName("Find closest color with invalid RGB values")
    void testFindClosestColorWithInvalidValues() {
        ColourTable colourTable = new ColourTable(16);
        colourTable.add(100, 100, 100);
        Throwable exception = assertThrows(IllegalArgumentException.class, () -> colourTable.findClosestColor(300, 100, 100));
        assertEquals("Invalid colour value provided", exception.getMessage());
    }

    @Test
    @DisplayName("String representation of an empty ColourTable")
    void testToStringEmptyPalette() {
        ColourTable colourTable = new ColourTable(16);
        assertEquals("ColourTable is empty.", colourTable.toString(), "Empty palette should return the correct message");
    }

    @Test
    @DisplayName("String representation of a ColourTable with colours")
    void testToStringWithColours() {
        ColourTable colourTable = new ColourTable(16);
        colourTable.add(100, 100, 100); // 646464
        colourTable.add(200, 200, 200); // C8C8C8
        String output = colourTable.toString();
        assertTrue(output.contains("646464"), "Output should include the added colour 646464");
        assertTrue(output.contains("C8C8C8"), "Output should include the added colour C8C8C8");
        assertTrue(output.startsWith("ColourTable: 2 colours"), "Output should start with the correct count");
    }
}

