import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class MainTest {
    @Test
    void basicTest() {
        assertEquals(1, 1); // A simple test to verify setup
    }
}
